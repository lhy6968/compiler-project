#include <cstdlib>
#include <fstream>
#include <iostream>
#include "assembling.h"
//#include "InstrImplement.h"
#include "dataBase.h"
#include "linker.h"
#include "LoaderAndSimulator.h"

using namespace std;

// to ask the user to input a valid filename.
string promptUserForFile(ifstream & stream, string prompt){
    while (true){
        string filename;
        cout << prompt;
        cin >> filename;
        stream.open(filename.c_str());
        if (!stream.fail()) {
            stream.close();
            return filename;
        }
        stream.clear();
        cout << "Unable to open that file. Please try again." << endl;
        if (prompt == "") prompt = "Input file: ";
    }
}

objInfo assember(string ifile_n){


    // part of assembling.
    ifstream ifile;
//    string ifile_n = promptUserForFile(ifile, "Input file: ");

    objInfo objif;
    ifile.open(ifile_n);
    recordSymbol(ifile, objif);
    ifile.close();
    ifile.open(ifile_n);
    assembling(ifile, objif);

    return objif;
}

int linking(vector<string> filevec){
    linker * mylinker = new linker;
    for (int i = 0; i < (int) filevec.size(); i++) {
        objInfo ojbif = assember(filevec[i]);
        mylinker->linkNewFile(& ojbif);
    }
    string ofile_n = "objlinker.txt";
    ofstream ofile(ofile_n);
//    cout << "formatout begin" << endl;
    formatOutput(ofile, *(mylinker->objifpt));
//    cout << "formatout done"  << endl;
    return 0;
}

int assmToimplement(vector<string> filevec){
    linking(filevec);
//    linker * mylinker = new linker;
//    objInfo objif1 = assember("C://Users/Charl/Desktop/test1.asm");
//    //objInfo objif2 = assember("H://test2.asm");

//    mylinker->linkNewFile(& objif1);
//    //mylinker->linkNewFile(& objif2);

//    string ofile_n = "objlinker.txt";
//    ofstream ofile(ofile_n);
//    cout << "formatout begin" << endl;
//    formatOutput(ofile, *(mylinker->objifpt));
//    cout << "formatout done"  << endl;
    cout << dec;
    loader();
    return 0;
}
