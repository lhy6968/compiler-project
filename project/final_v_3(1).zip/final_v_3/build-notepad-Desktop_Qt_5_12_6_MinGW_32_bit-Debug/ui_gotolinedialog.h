/********************************************************************************
** Form generated from reading UI file 'gotolinedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GOTOLINEDIALOG_H
#define UI_GOTOLINEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GoToLineDialog
{
public:
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *label_3;
    QWidget *tab_3;
    QLabel *label_2;
    QWidget *tab_2;
    QLabel *label;

    void setupUi(QWidget *GoToLineDialog)
    {
        if (GoToLineDialog->objectName().isEmpty())
            GoToLineDialog->setObjectName(QString::fromUtf8("GoToLineDialog"));
        GoToLineDialog->resize(601, 353);
        verticalLayout = new QVBoxLayout(GoToLineDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tabWidget = new QTabWidget(GoToLineDialog);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setTabPosition(QTabWidget::South);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(0, 0, 571, 301));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        label_2 = new QLabel(tab_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 571, 301));
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        label = new QLabel(tab_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 571, 301));
        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);


        retranslateUi(GoToLineDialog);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(GoToLineDialog);
    } // setupUi

    void retranslateUi(QWidget *GoToLineDialog)
    {
        GoToLineDialog->setWindowTitle(QApplication::translate("GoToLineDialog", "Form", nullptr));
        label_3->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("GoToLineDialog", "Problems", nullptr));
        label_2->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("GoToLineDialog", "Compile Output", nullptr));
        label->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("GoToLineDialog", "Debugger Console", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GoToLineDialog: public Ui_GoToLineDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GOTOLINEDIALOG_H
