/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../notepad8/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[37];
    char stringdata0[401];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 14), // "currentChanged"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 5), // "index"
QT_MOC_LITERAL(4, 33, 19), // "modificationChanged"
QT_MOC_LITERAL(5, 53, 7), // "changed"
QT_MOC_LITERAL(6, 61, 16), // "selectionChanged"
QT_MOC_LITERAL(7, 78, 17), // "blockCountChanged"
QT_MOC_LITERAL(8, 96, 10), // "blockCount"
QT_MOC_LITERAL(9, 107, 8), // "openFile"
QT_MOC_LITERAL(10, 116, 8), // "FileName"
QT_MOC_LITERAL(11, 125, 7), // "newFile"
QT_MOC_LITERAL(12, 133, 10), // "fileSaveAs"
QT_MOC_LITERAL(13, 144, 8), // "fileSave"
QT_MOC_LITERAL(14, 153, 3), // "run"
QT_MOC_LITERAL(15, 157, 11), // "fileSaveAll"
QT_MOC_LITERAL(16, 169, 9), // "fileClose"
QT_MOC_LITERAL(17, 179, 12), // "fileCloseAll"
QT_MOC_LITERAL(18, 192, 8), // "gotoLine"
QT_MOC_LITERAL(19, 201, 6), // "search"
QT_MOC_LITERAL(20, 208, 9), // "textColor"
QT_MOC_LITERAL(21, 218, 8), // "textFont"
QT_MOC_LITERAL(22, 227, 14), // "textFontFamily"
QT_MOC_LITERAL(23, 242, 4), // "font"
QT_MOC_LITERAL(24, 247, 8), // "textSize"
QT_MOC_LITERAL(25, 256, 4), // "size"
QT_MOC_LITERAL(26, 261, 9), // "textStyle"
QT_MOC_LITERAL(27, 271, 19), // "updateTextStyleActs"
QT_MOC_LITERAL(28, 291, 5), // "style"
QT_MOC_LITERAL(29, 297, 10), // "nextWindow"
QT_MOC_LITERAL(30, 308, 14), // "previousWindow"
QT_MOC_LITERAL(31, 323, 16), // "currentAllWindow"
QT_MOC_LITERAL(32, 340, 16), // "setCurrentWindow"
QT_MOC_LITERAL(33, 357, 8), // "QAction*"
QT_MOC_LITERAL(34, 366, 1), // "a"
QT_MOC_LITERAL(35, 368, 14), // "openRecentFile"
QT_MOC_LITERAL(36, 383, 17) // "updateRecentFiles"

    },
    "MainWindow\0currentChanged\0\0index\0"
    "modificationChanged\0changed\0"
    "selectionChanged\0blockCountChanged\0"
    "blockCount\0openFile\0FileName\0newFile\0"
    "fileSaveAs\0fileSave\0run\0fileSaveAll\0"
    "fileClose\0fileCloseAll\0gotoLine\0search\0"
    "textColor\0textFont\0textFontFamily\0"
    "font\0textSize\0size\0textStyle\0"
    "updateTextStyleActs\0style\0nextWindow\0"
    "previousWindow\0currentAllWindow\0"
    "setCurrentWindow\0QAction*\0a\0openRecentFile\0"
    "updateRecentFiles"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  174,    2, 0x08 /* Private */,
       4,    1,  177,    2, 0x08 /* Private */,
       6,    0,  180,    2, 0x08 /* Private */,
       7,    1,  181,    2, 0x08 /* Private */,
       9,    0,  184,    2, 0x08 /* Private */,
       9,    1,  185,    2, 0x08 /* Private */,
      11,    0,  188,    2, 0x08 /* Private */,
      12,    1,  189,    2, 0x08 /* Private */,
      13,    1,  192,    2, 0x08 /* Private */,
      12,    0,  195,    2, 0x08 /* Private */,
      13,    0,  196,    2, 0x08 /* Private */,
      14,    0,  197,    2, 0x08 /* Private */,
      14,    1,  198,    2, 0x08 /* Private */,
      15,    0,  201,    2, 0x08 /* Private */,
      16,    1,  202,    2, 0x08 /* Private */,
      16,    0,  205,    2, 0x08 /* Private */,
      17,    0,  206,    2, 0x08 /* Private */,
      18,    0,  207,    2, 0x08 /* Private */,
      19,    0,  208,    2, 0x08 /* Private */,
      20,    0,  209,    2, 0x08 /* Private */,
      21,    0,  210,    2, 0x08 /* Private */,
      22,    1,  211,    2, 0x08 /* Private */,
      24,    1,  214,    2, 0x08 /* Private */,
      26,    1,  217,    2, 0x08 /* Private */,
      26,    0,  220,    2, 0x08 /* Private */,
      27,    1,  221,    2, 0x08 /* Private */,
      29,    0,  224,    2, 0x08 /* Private */,
      30,    0,  225,    2, 0x08 /* Private */,
      31,    0,  226,    2, 0x08 /* Private */,
      32,    1,  227,    2, 0x08 /* Private */,
      35,    0,  230,    2, 0x08 /* Private */,
      36,    0,  231,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Int,    3,
    QMetaType::Bool, QMetaType::Int,    3,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool, QMetaType::Int,    3,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 33,   34,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->modificationChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->selectionChanged(); break;
        case 3: _t->blockCountChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->openFile(); break;
        case 5: _t->openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->newFile(); break;
        case 7: { bool _r = _t->fileSaveAs((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: { bool _r = _t->fileSave((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 9: { bool _r = _t->fileSaveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 10: { bool _r = _t->fileSave();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 11: { bool _r = _t->run();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 12: { bool _r = _t->run((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 13: { bool _r = _t->fileSaveAll();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 14: _t->fileClose((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->fileClose(); break;
        case 16: _t->fileCloseAll(); break;
        case 17: _t->gotoLine(); break;
        case 18: _t->search(); break;
        case 19: _t->textColor(); break;
        case 20: _t->textFont(); break;
        case 21: _t->textFontFamily((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->textSize((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 23: _t->textStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 24: _t->textStyle(); break;
        case 25: _t->updateTextStyleActs((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->nextWindow(); break;
        case 27: _t->previousWindow(); break;
        case 28: _t->currentAllWindow(); break;
        case 29: _t->setCurrentWindow((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 30: _t->openRecentFile(); break;
        case 31: _t->updateRecentFiles(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
